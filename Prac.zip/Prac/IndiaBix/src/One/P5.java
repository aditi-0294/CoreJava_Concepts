/*package One;

public class P5 extends NewTreeSet{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		NewTreeSet2 t = new NewTreeSet2();
        t.count();

	}
	
	protected void count {
		
	}

}
*/
package One ;

import java.util.LinkedHashSet;

public class P5 {
	
	public static void main(String args[]) throws Exception {
		
		/*
		LinkedHashSet hs=new LinkedHashSet(); 
		hs.add(""a""); 
		hs.add(""b""); 
		hs.add(null); 
		System.out.println( hs.add(""b"")); 
		System.out.println(hs); 
	*/
	/*boolean var1 = true ;
		boolean var2 = false ;
	
	System.out.println(var2||var2);
	*/
	
		
		/*char a = 'E' ;
	System.out.println((int)a++);
	
	
	double r , pi , m ;
	r = 9.8 ;
	pi = 3.14 ;
	
	m = pi * r * r ;
	
	System.out.println(m);
	*/
	
	/*
		int h=9; 
		int a=++h + ++h + --h + h--; 
		System.out.println(a); 
	
	*/
	
		/* int w = (int)888.8; 
		  byte x = (byte)100L; 
		  long y = (byte)100; 
		  byte z = (byte)100L;
	*/
		/*int x=0xF; 
		for(;x<15;) 
		{ 
		System.out.print(x); 
		x++; 
		} 
	*/
	
	
	System.out.println("G".compareTo("Z"));
	
	}
	
	
}