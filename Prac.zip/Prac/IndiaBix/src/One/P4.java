package One;

public class P4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Math.max(1,4) ;
	//	Math.max(1,2,3,4) ;
		Math.max(2.5, 3) ;

	}

}
