package One;

public class P1 {
	
	 void P1() /* Line 3 */
	    {
	        System.out.println("Class A"); 
	    } 

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		new P1() ;
	}

}
