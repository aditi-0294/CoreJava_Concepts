import java.util.Scanner;

public class Pattern_1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner input = new Scanner(System.in) ;
		
		System.out.println("Enter number of lines to print : ");
		int lines = input.nextInt() ;
		
		System.out.println("The pattern is : ");
		
		for(int row = 0 ; row < lines ; row++) {
			
			for(int column = row ; column < lines ; column++) {
				
				System.out.print("*");
			}
			
			System.out.println();
		}

	}

}

/* Pattern starts
Enter number of lines to print : 
5
*****
****
***
**
*
pattern ends */