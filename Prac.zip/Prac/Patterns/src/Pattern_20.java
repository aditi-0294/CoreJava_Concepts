import java.util.Scanner;

public class Pattern_20 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner input = new Scanner(System.in) ;
		
		System.out.println("Enter number of lines : ");
		int lines = input.nextInt() ;
		
		for(int row = 1 ; row <= lines ; row++) {
			
			for(int column = 1 ; column < row ; column++) {
				
				System.out.print(" ");
			}
			
			for(int column = row ; column <= lines ; column++) {
				
				System.out.print("* ");
			}
			
			System.out.println();
		}
	}

}

/* Pattern starts

Enter number of lines : 
5
* * * * * 
 * * * * 
  * * * 
   * * 
    * 

Pattern ends */