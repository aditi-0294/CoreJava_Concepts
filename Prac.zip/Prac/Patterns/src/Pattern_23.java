import java.util.Scanner;

public class Pattern_23 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner input = new Scanner(System.in) ;
		
		System.out.println("Enter number of lines : ");
		int lines = input.nextInt() ;
		
		System.out.println("The pattern is : ");
		
		for(int row = 1 ; row <= lines ; row++) {
			
			for(int column = 1 ; column <= row ; column++) {
				
				if(column % 2 == 0)
					System.out.print("0 ");
				else
					System.out.print("1 ");
			}
			
			System.out.println();
		}

	}

}


/* Pattern starts

Enter number of lines : 
7
The pattern is : 
1 
1 0 
1 0 1 
1 0 1 0 
1 0 1 0 1 
1 0 1 0 1 0 
1 0 1 0 1 0 1 

Pattern ends */