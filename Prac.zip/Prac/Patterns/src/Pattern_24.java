import java.util.Scanner;

public class Pattern_24 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner input = new Scanner(System.in) ;
		
		System.out.println("Enter number of lines : ");
		int lines = input.nextInt() ;
		
		int num ;
		
		for(int row = 1 ; row <= lines ; row++) {
			
			if(row % 2 == 0) {
				
				num = 0 ;
				
				for(int column = 1 ; column <= lines ; column++) {
					
					System.out.print(num);
					
					num = (num == 0) ? 1 : 0 ;
					
				}
				
			}
			
			
			else {
				
				num = 1 ;
				
				for(int column = 1 ; column <= lines ; column++) {
					
					System.out.print(num);
					
					num = (num == 0) ? 1 : 0 ;
					
				}
			}
			
			System.out.println();
			

		}
		
		
	}

}

/* Pattern start 

Enter number of lines : 
7
1010101
0101010
1010101
0101010
1010101
0101010
1010101

Pattern end */