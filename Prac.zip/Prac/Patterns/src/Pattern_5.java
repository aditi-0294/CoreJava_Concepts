import java.util.Scanner;

public class Pattern_5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner input = new Scanner(System.in) ;
		
		System.out.print("Enter number of lines : ");
		int lines = input.nextInt() ;
		
		System.out.println("The pattern is : ");
		
		int num = 1 ;
		
		for(int row = 0 ; row < lines ; row++) {
			
			for(int column = 0 ; column <= row ; column++) {
			
				System.out.print(num + " ");
				num++ ;
				
			}
			
			System.out.println();
		}
		
	}

}

/* Pattern starts
 Enter number of lines : 5
The pattern is : 
1 
2 3 
4 5 6 
7 8 9 10 
11 12 13 14 15 
Pattern ends */ 
 