import java.util.Scanner;

public class Pattern_7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner input = new Scanner(System.in) ;
		
		System.out.print("Enter number of lines : ");
		int lines = input.nextInt();
		
		System.out.println("The pattern is : ");
		
		for(int row = 1 ; row <= lines ; row++) {
			
			for(int column = 0 ; column < row ; column++) {
				
				System.out.print(row + " ");
			}
			
			System.out.println();
		}
	}

}

/* Pattern starts
Enter number of lines : 
5
The pattern is : 
1 
2 2 
3 3 3 
4 4 4 4 
5 5 5 5 5 

Pattern ends */
