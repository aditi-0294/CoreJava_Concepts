import java.util.Scanner;

public class Pattern_22 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner input = new Scanner(System.in) ;
		
		System.out.println("Enter number of lines : ");
		int lines = input.nextInt() ;
		
		System.out.println("THe pattern is : ");
		
		for(int row = 1 ; row <= lines ; row++) {
			
			for(int column = 1 ; column < row ; column++) {
				
				System.out.print(" ");
				
			}
			
			for(int column = row ; column <= lines ; column++) {
				
				System.out.print(column + " ");
				
			}
			
			System.out.println();
		}
		
		
		
		for(int row = lines - 1 ; row > 0 ; row--) {
			
			for(int column = 1 ; column < row ; column++) {
				
				System.out.print(" ");
			
			}
			
			for(int column = row ; column <= lines ; column++) {
				
				System.out.print(column + " ");
				
			}
			
			System.out.println();
		
		
		}

	}
	
}


/* Pattern start

Enter number of lines : 
7
THe pattern is : 
1 2 3 4 5 6 7 
 2 3 4 5 6 7 
  3 4 5 6 7 
   4 5 6 7 
    5 6 7 
     6 7 
      7 
     6 7 
    5 6 7 
   4 5 6 7 
  3 4 5 6 7 
 2 3 4 5 6 7 
1 2 3 4 5 6 7 

Pattern ends */