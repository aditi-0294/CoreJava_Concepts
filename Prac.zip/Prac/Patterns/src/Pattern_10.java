import java.util.Scanner;

public class Pattern_10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner input = new Scanner(System.in) ;
		
		System.out.print("Enter number of lines : ");
		int lines = input.nextInt() ;
		
		System.out.println("The pattern is : ");

		
		for(int row = 1 ; row <= lines ; row++) {
			
			for(int column = 1 , num = 1 ; column <= row ; column++) {
				
				System.out.print(num + " ");
				num++ ;
				
			}
		
			System.out.println();
		}
	}

}

/* Pattern starts
Enter number of lines : 5
The pattern is : 
1 
1 2 
1 2 3 
1 2 3 4 
1 2 3 4 5 

Pattern ends */