import java.util.Scanner;

public class Pattern_2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner input = new Scanner(System.in) ;
		
		System.out.println("Number of lines : ");
		int lines = input.nextInt() ;
		
		System.out.println("The pattern is : ");
		
		for(int row = 1 ; row <= lines ; row++) {
			
			for(int column = 0 ; column < row ; column++ ) {
				
				System.out.print("*");
			
			}
		
			System.out.println();
		}

	}

}

/* Pattern starts
 Number of lines : 
5
The pattern is : 
*
**
***
****
*****

 Pattern ends */ 
