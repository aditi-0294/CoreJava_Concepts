import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class Example_1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			
			// Loading driver ( database driver )
			Class.forName("org.h2.Driver") ;
			System.out.println("H2 database driver loaded successfully ... ");
			
			// Create connection object
			Connection con = DriverManager.getConnection("jdbc:h2:tcp://localhost/~/jdbc", "aditi", "sanaditi") ;
			System.out.println("Connection object created successfully ... ");
			
			// Create statement object
			Statement stmt = con.createStatement() ;
			System.out.println("Statement object created successfully ... ");
			
			//  Create ResultSet 
			String str = "Select * from Author where city like 'S%'" ;
			ResultSet rs = stmt.executeQuery(str) ;
			System.out.println("ResultSet object created successfully ... ");
			
			System.out.println();
			
			System.out.println("Author_Id (au_id) \t Author_Name (au_name) \t City");
			
			System.out.println("--------------------------------------------------------");
			
			while(rs.next()) {
				
				String id = rs.getString("au_id") ;
				String name = rs.getString("au_name") ;
				String city = rs.getString("city") ;
				
				/* table not properly aligned */
				
				System.out.println(id + "\t");
				System.out.println("\t\t" + name + "\t");
				System.out.println("\t\t" + city + "\t");
			}
		} catch(Exception e) {
			
			System.out.println("Error occured : " + e);
		}

	}

}
