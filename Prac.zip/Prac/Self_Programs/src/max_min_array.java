import java.util.Scanner;

public class max_min_array {
	
	public void max_min() {
		
		Scanner sc = new Scanner(System.in) ;
		
		System.out.println("Enter array range : ");
		int num = sc.nextInt() ;
		
		int arr[] = new int[num] ;
		
		System.out.println("Enter array elements : ");
		
		for(int i = 0 ; i < num ; i++ ) {
			arr[i] = sc.nextInt() ;
		}
		
		System.out.println("Displaying array elements : ");
		
		for(int i = 0 ; i < num ; i++) {
			System.out.println(arr[i]);
		}
		
		for(int i = 0 ; i < num ; i++) {
			
			for(int j = i + 1 ; j < num ; j++) {
			
				if(arr[i] > arr[j]) {
					
					int temp = arr[i] ;
					arr[i] = arr[j] ;
					arr[j] = temp ;
					
				}
			}
		}
		
		System.out.println("Minimum number = " + arr[0]);
		System.out.println("Maximum number = " + arr[num-1]);
		
		System.out.println("Second largest number = " + arr[num-2]);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		max_min_array mna = new max_min_array() ;
		mna.max_min();

	}

}
