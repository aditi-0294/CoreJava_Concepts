package TreeSet_Collection;

import java.util.TreeSet;

public class TreeSetDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		TreeSet<String> treeset = new TreeSet<String>() ;
		
		treeset.add("Shweta") ;
		treeset.add("Prince") ;
		treeset.add("Aditi") ;
		
		System.out.println(treeset); // [Aditi, Prince, Shweta]
		
		TreeSet<Employee> employee_treeset = new TreeSet<Employee>() ;
		
		employee_treeset.add(new Employee(1001 , "Shweta" , -10000)) ;
		employee_treeset.add(new Employee(1002 , "Aditi" , 0)) ;
		employee_treeset.add(new Employee(1003 , "Prince" , 12000)) ;
		employee_treeset.add(new Employee(1004 , "Bruce" , 14000)) ;
		
		for(Employee employee : employee_treeset) {
			
			System.out.println(employee);
			
			/*
			    TreeSet_Collection.Employee@15db9742
				TreeSet_Collection.Employee@6d06d69c
				TreeSet_Collection.Employee@7852e922
				TreeSet_Collection.Employee@4e25154f

			 */
		
		}
		
		/*
		 
					if(this.salary > arg0.salary)
							return 1 ;
					else
						if(this.salary < arg0.salary)
							return -1 ;
					else
						return 0 ;
	
	
					public String toString() {
			
							return "Employee ID : " + emp_id + "Employee Name : " + emp_name + "Employee Salary : " + salary ;
			
						}
		
		
		Employee ID : 1001Employee Name : ShwetaEmployee Salary : 10000.0
		Employee ID : 1003Employee Name : PrinceEmployee Salary : 12000.0
		Employee ID : 1004Employee Name : BruceEmployee Salary : 14000.0
		Employee ID : 1002Employee Name : AditiEmployee Salary : 19000.0

		
		
		*/
		
		
		
		/*
		 		if(this.salary > arg0.salary)
					return 0 ;
				else
					if(this.salary < arg0.salary)
						return -1 ;
					else
						return 1 ;
	
				//	Employee ID : 1001 Employee Name : Shweta Employee Salary : -10000.0
				 
		 */

		
	}

}
