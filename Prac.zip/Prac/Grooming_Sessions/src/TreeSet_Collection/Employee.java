package TreeSet_Collection;

public class Employee implements Comparable<Employee> {
	
	int emp_id ;
	String emp_name ;
	double salary ;
	
	public Employee(int emp_id , String emp_name , double salary) { 
		
		// class scope and member scope variables should be different .
		
		this.emp_id = emp_id ;
		this.emp_name = emp_name ;
		this.salary = salary ;
		
	}

	@Override
	public int compareTo(Employee arg0) {
		// TODO Auto-generated method stub
		
		if(this.salary > arg0.salary)
			return 1 ;
		else
			if(this.salary < arg0.salary)
				return -1 ;
			else
				return 0 ;
	
	}
	
	
	
	public String toString() {
		
		return "Employee ID : " + emp_id + " Employee Name : " + emp_name + " Employee Salary : " + salary ;
		
	}
	


}
