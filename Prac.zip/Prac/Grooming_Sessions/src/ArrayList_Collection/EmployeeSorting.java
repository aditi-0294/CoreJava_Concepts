package ArrayList_Collection;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class EmployeeSorting {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int option ;

		ArrayList<Employee> employee_list = new ArrayList<Employee>() ;
		employee_list.add(new Employee(1001 , "Aditi" , 20000)) ;
		employee_list.add(new Employee(1002 , "Aakash" , 25000)) ;
		employee_list.add(new Employee(1005 , "Aditi" , 25000)) ;
		employee_list.add(new Employee(1003 , "Khushi" , 30000)) ;
		employee_list.add(new Employee(1004 , "Karan" , 35000)) ;
		
		do {
			
			System.out.println("Enter choice : ");
			System.out.println("1. Name Wise Sorting");
			System.out.println("2. Salary Wise Sorting");
			
			Scanner sc = new Scanner(System.in) ;
			option = sc.nextInt() ;
			
			switch(option) {
			
			case 1 : 
				NameWiseSort sortByName = new NameWiseSort() ;
				Collections.sort(employee_list , sortByName);
				break ;
				
			case 2 :
				SalaryWiseSort sortBySalary = new SalaryWiseSort() ;
				Collections.sort(employee_list , sortBySalary);
				break ;
				
			default :
				System.out.println("Invalid option !!!");
			}

			
			for(Employee employee : employee_list) {
				
				System.out.println(employee);
				
			}
			
			System.out.println();
						
		} while(true) ;
		
	}

}

/*	Name Wise Sorting : 
Employee ID : 1002 Employee Name : Aakash Employee Salary : 25000.0
Employee ID : 1001 Employee Name : Aditi Employee Salary : 20000.0
Employee ID : 1005 Employee Name : Aditi Employee Salary : 25000.0
Employee ID : 1004 Employee Name : Karan Employee Salary : 35000.0
Employee ID : 1003 Employee Name : Khushi Employee Salary : 30000.0
*/


/*	Salary Wise Sorting :
Employee ID : 1001 Employee Name : Aditi Employee Salary : 20000.0
Employee ID : 1002 Employee Name : Aakash Employee Salary : 25000.0
Employee ID : 1005 Employee Name : Aditi Employee Salary : 25000.0
Employee ID : 1003 Employee Name : Khushi Employee Salary : 30000.0
Employee ID : 1004 Employee Name : Karan Employee Salary : 35000.0
*/