/**
 * 
 */

console.log("controller.js loaded") ;

/*app.controller("MainController" , function($scope) {
*/	
	
app.controller("mc" , function($scope) {

console.log("controller.js - app.controller ")
	
	$scope.username = username ;
	
}) ;