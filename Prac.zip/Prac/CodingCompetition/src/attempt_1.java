import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.event.MenuKeyEvent;
import javax.swing.event.MenuKeyListener;

class MyKeyListener extends KeyAdapter {
	
	@Override
	public void keyPressed(KeyEvent event) {
		
		char ch = event.getKeyChar() ;
		
		System.out.println(ch);
		
		if(event.getKeyCode() == KeyEvent.VK_HOME) {
			
			System.out.println("Key codes : " + event.getKeyCode());
		}
	}
	
}
public class attempt_1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		JTextField text_field = new JTextField() ;
		
		text_field.addKeyListener(new MyKeyListener());
		
		JFrame j_frame = new JFrame() ;
		
		j_frame.add(text_field) ;
		
		j_frame.setSize(400, 250);
		
		j_frame.setVisible(true);

	}

}
