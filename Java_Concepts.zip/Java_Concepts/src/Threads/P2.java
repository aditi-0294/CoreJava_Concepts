package Threads;

import java.io.IOException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class P2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ExecutorService es = Executors.newCachedThreadPool() ;
		es.execute(new P1("one"));
		es.execute(new P1("two"));
		es.shutdown();
		
		try {
			es.awaitTermination(5, TimeUnit.SECONDS) ;
		} catch(InterruptedException ie) {
			System.out.println("InterruptedException : " + ie);
		}
	}

}
