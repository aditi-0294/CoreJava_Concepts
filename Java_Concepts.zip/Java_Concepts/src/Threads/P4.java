package Threads;

import java.util.concurrent.atomic.AtomicInteger;

public class P4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		AtomicInteger ai = new AtomicInteger(5);
		System.out.println(ai.incrementAndGet());
	}

}
