package Threads;

import java.util.concurrent.Callable;

public class P3 implements Callable {

	private final String name ;
	private final int len ;
	private int sum = 0 ;
	
	public P3(String name , int len) {
		
		this.name = name ;
		this.len = len ;
		
	}

	@Override
	public Object call() throws Exception {
		// TODO Auto-generated method stub
		for(int i = 0 ; i < len ; i++) {
			System.out.println(name + " : " + i);
			sum = sum + i ;
		}
		return "sum = " + sum ;
	}
	}
	
	

