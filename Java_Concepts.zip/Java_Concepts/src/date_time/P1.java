package date_time;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

public class P1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		LocalDateTime meeting , flight , courseStart , courseEnd ;
		
		meeting = LocalDateTime.of(2017, 12, 13, 9, 30) ;
		System.out.println("Meeting is on : " + meeting);
		System.out.println();
		
		LocalDate flightDate = LocalDate.of(2017, 12, 14) ;
		LocalTime flightTime = LocalTime.of(14, 30) ;
		flight = LocalDateTime.of(flightDate , flightTime) ;
		System.out.println("Flight details : " + flight);
		System.out.println();
		
		courseStart = LocalDateTime.of(2017, 12, 03, 8, 30) ;
		courseEnd = courseStart.plusDays(4).plusHours(10) ;
		System.out.println("Course start : " + courseStart);
		System.out.println("course End : " + courseEnd);
		System.out.println();
		
		//long courseHrs = (courseEnd.getHour() - courseStart.getHour()) * (courseStart.until(courseEnd, null) + 1);
		//System.out.println("course duration : " + courseHrs);
		
	}

}
