package time;

import java.time.LocalTime;
import java.time.temporal.ChronoUnit;


public class P1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		LocalTime now , nowPlus , nowHrsMins , lunch , bedTime ;
		
		now = LocalTime.now() ;
		System.out.println("Time now is : " + now);
		System.out.println();
		
		nowPlus = now.plusHours(1).plusMinutes(15) ;
		System.out.println("Time after 1hr 15 mins : " + nowPlus);
		System.out.println();
		
	//	nowHrsMins = now.truncatedTo(Minutes) ;
		
		lunch = LocalTime.of(12,30) ;
		System.out.println("Is lunch after : " + lunch.isAfter(now));
		System.out.println();
		
	//	long minsToLunch = now.until(lunch, ) ;
		
	}

}
