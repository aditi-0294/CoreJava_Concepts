package io_streams;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class P1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		byte[] b = new byte[128];
		
		// create a file to avoid exception in catch  block
		try(FileInputStream fis = new FileInputStream("E:\\Mastek\\Files\\P1.txt") ;
				FileOutputStream fos = new FileOutputStream("E:\\Mastek\\Files\\P1.txt")
			) {
			
			System.out.println("Bytes available : " + fis.available());
			
			int read = 0 , count = 0 ;
			
			while((read = fis.read(b)) != -1) {
				fos.write(b);
				count = count + read ;
			}
			
			System.out.println("words written = " + count);
			
			
		} catch(FileNotFoundException f) {
			
			System.out.println("File Not Found Exception : " + f);
			
		} catch(IOException ex) {
			
			System.out.println("IOException : " + ex);
		}
		
		

	}

}
