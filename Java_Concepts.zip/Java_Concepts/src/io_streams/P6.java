package io_streams;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class P6 {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		try {
				@SuppressWarnings("resource")
				BufferedReader bReader = new BufferedReader(new FileReader("E:\\Mastek\\Files\\P6.txt")) ;
				System.out.println("Entire file : ");
				
				bReader.lines()
					   .forEach(line -> System.out.println(line));
				
			} catch(FileNotFoundException f) {
				System.out.println("FileNotFoundException : " + f);
			}

		
	}
}
