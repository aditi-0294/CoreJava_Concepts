package io_streams;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;

public class P5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try(FileChannel fcIn = new FileInputStream("E:\\Mastek\\Files\\P3.txt").getChannel() ;
				FileChannel fcOut = new FileOutputStream("E:\\Mastek\\Files\\P3.txt").getChannel()
						) {
			
			ByteBuffer buff = ByteBuffer.allocate((int) fcIn.size()) ;
			System.out.println(buff.position());
			fcIn.read(buff) ;
			buff.position(0) ;
			fcOut.write(buff) ;
						
		} catch(FileNotFoundException f) {
			System.out.println("FileNotFoundException : " + f);
		} catch(IOException ex) {
			System.out.println("IOException : " + ex);
		}

	}

}
