package io_streams;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class P2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		char[] b = new char[128];

		// create a file to avoid exception in catch block
		try (FileReader fr = new FileReader("E:\\Mastek\\Files\\P2.txt");
				FileWriter fw = new FileWriter("E:\\Mastek\\Files\\P2.txt")) {

	//		System.out.println("Bytes available : " + fr.available());

			int read = 0, count = 0;

			while ((read = fr.read(b)) != -1) {
				fw.write(b);
				count = count + read;
			}

			System.out.println("words written = " + count);

		} catch (FileNotFoundException f) {

			System.out.println("File Not Found Exception : " + f);

		} catch (IOException ex) {

			System.out.println("IOException : " + ex);
		}

	}

}
