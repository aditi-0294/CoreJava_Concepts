package io_streams;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.stream.Stream;

public class P7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try(Stream<String> lines = Files.lines(Paths.get("E:\\Mastek\\Files\\P6.txt"))) {
			
			System.out.println("Entire file : ");
			lines.forEach(line -> System.out.println(line));
			
		} catch(IOException ex) {
			System.out.println("IOException : " + ex);
		}

	}

}
