package io_streams;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.stream.Stream;

public class P8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		List<String> fileArr ;
		Path file = Paths.get("E:\\Mastek\\Files\\P6.txt") ;
		
		try {
			fileArr = Files.readAllLines(file);
			System.out.println("readAllLines method executed : ");
			
			fileArr.stream()
				   .filter(line -> line.contains("jkd"))
				   .forEach(line -> System.out.println(line));
			
			System.out.println("Word count : ");
			long wordCount = fileArr.stream()
				   .flatMap(line -> Stream.of(line.split(" ")))
				   .filter(word -> word.contains("jkd"))
				   .peek(word -> System.out.println(word)) 
				   .count();
			
			System.out.print(wordCount);
		} catch(IOException ex) {
			System.out.println("IOException : " + ex);
		}

	}

}
