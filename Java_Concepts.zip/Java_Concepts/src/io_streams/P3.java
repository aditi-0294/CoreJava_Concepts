package io_streams;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class P3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String line = "" ;
		int count = 0;
		
		try(BufferedReader bufInput = new BufferedReader(new FileReader("E:\\Mastek\\Files\\P3.txt")) ;
				BufferedWriter bufOutput = new BufferedWriter(new FileWriter("E:\\Mastek\\Files\\P3.txt"))
						) {
			
			while((line = bufInput.readLine()) != null) {
				bufOutput.write(line);
				bufOutput.newLine();
				count++ ;
			}
			
			System.out.println("Words written : " + ++count);
			
		} catch (FileNotFoundException f) {
			
			System.out.println("FileNotFoundException : " + f);
		
		} catch(IOException ex) {
			
			System.out.println("IOException : " + ex);
		}

	}

}
