package localization;

import java.time.format.DateTimeFormatter;

public class P2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ResourceBundle.
	}

}
