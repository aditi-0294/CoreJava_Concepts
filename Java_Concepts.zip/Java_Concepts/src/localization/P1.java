package localization;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Properties;

public class P1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//P1 mp = new P1() ;
		Properties mp = new Properties();
		FileInputStream fis;
		try {
			fis = new FileInputStream("ServerInfo.properties");
			System.out.println(mp.);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		mp.load(fis) ;
		

	}

}
