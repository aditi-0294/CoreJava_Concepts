package date;

import java.time.LocalDate;
import java.time.temporal.*;

public class P1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		LocalDate now , bDate , nowPlusMonths , nextTues;
		
		now = LocalDate.now() ;
		System.out.println("Current date : " + now);
		System.out.println();
		
		bDate = LocalDate.of(1995, 5, 23) ;
		System.out.println("JAVA's birthdate : " + bDate);
		System.out.println("Is birthday in the past ? " + bDate.isBefore(now));
		System.out.println("Is birthday in leap year ?" + bDate.isLeapYear());
		System.out.println("Birthdate day of week : " + bDate.getDayOfWeek());
		System.out.println();
		
		nowPlusMonths = now.plusMonths(1) ;
		System.out.println("Date of month from now : " + nowPlusMonths );
		System.out.println();
		
		nextTues = now.with(nowPlusMonths) ;
		System.out.println("Next tuesdays' date : " + nextTues);
		
		
		
	}

}
