package interface2;

import java.io.*;

class MyClass implements AutoCloseable {  // line n1
    public void close( ) throws IOException {  // line n2
        System.out.println("I'm closed");
    }
    public void open( ) {
        System.out.println("I'm open");
    }
}
