package interface2;

public class TestMyClass {
    public static void main(String[ ] args) throws Exception {  // line n3
        try (MyClass mc = new MyClass( )) {   // line n4
            mc.open( );
        }
    }
}
