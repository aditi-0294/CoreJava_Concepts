import java.util.*;

public class P33 {
    int id;
    String name;
    String department;
    P33(int id, String name, String department) {
        this.id = id;
        this.name = name;
        this.department = department;
    }

    public int getEmployeeId( ) {
        return id;
    }
    public String getEmployeeName( ) {
        return name;
    }
    public String getDept( ) {
        return department;
    }

    public static void main(String[ ] args) {
        List<P33> employeeList = new ArrayList<>( );
        employeeList.add(new P33(13, "Dave", "Programmer"));
        employeeList.add(new P33(20, "John", "Finance"));
        employeeList.add(new P33(31, "Cathy", "Human Resources"));
        employeeList
            .stream( )
            .filter(s -> s.getEmployeeId() > 15)
            .sorted((s1, s2) -> Integer.compare(s1.getEmployeeId(), s2.getEmployeeId()))
            .mapToInt(s -> s.getEmployeeId( ))
            .forEach(s -> System.out.println(s));
    }
}