import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class P11 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		List<String> myList = new ArrayList<>( );
		       
		         try (BufferedReader br = new BufferedReader(new FileReader("E:\\Mastek\\Files\\P11.txt"))) {
		             String a = null;
		             while((a = br.readLine( )) != null) {
		                 try {
		                     int b = Integer.parseInt(a.substring(0, 3));
		                 } catch(NumberFormatException ex) {
		                     myList.add(a);
		                 }
		             }
		         } catch (IOException e) {
		             System.out.println(e.getMessage( ));
		         }
		 
		         for(String a: myList) {
		             System.out.println(a);
		         }
	}

}
