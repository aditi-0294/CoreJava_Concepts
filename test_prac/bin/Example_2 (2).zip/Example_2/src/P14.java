import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

public class P14 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		List<String> names = Arrays.asList("Jan", "Julio",  "Iris", "Alden", "Ernie", "Graham", "Ben", "Mario");
		         Comparator<String> compareLength = (str1, str2) -> str1.length() - str2.length();
		         names.stream()
		              .distinct()
		              .sorted(compareLength.thenComparing(String::compareTo))
		              .forEach(System.out::println);
	}

}
