import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.stream.Stream;

public class P34 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		/*
		 * String a = "/Java Code/Temp"; String b = "/Java Code/Temp1"; Path
		 * path1 = FileSystems.getDefault( ).getPath(a); Path path2 =
		 * FileSystems.getDefault( ).getPath(b);
		 * 
		 * try { Files.move(path1, path2); } catch (IOException e) {
		 * System.out.println("error: " + e.toString( )); }
		 */

		try (Stream<Path> stream = Files.walk(Paths.get("c:\\JavaCode"))) {
			stream.map(String::valueOf).filter(path -> path.endsWith(".java")).forEach(System.out::println);
		}
	}

}
