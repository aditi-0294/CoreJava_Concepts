import java.util.ArrayList;
import java.util.List;

class Record{String status="";String message="";}

public class P16 {
	

	public static void main(String[] args) {
		processData(generateList(), s -> s % 2 == 1);
	}

	public static void processData(List<Integer> data, Predicate<int> tester) {
		         for(int s: data) {
		             if(tester.test(s)) {
		                 System.out.println(s);
		             }
		         }
		     }

	public static List<Integer> generateList() {
		List<Integer> data = new ArrayList<>();
		data.add(1);
		data.add(2);
		data.add(3);
		data.add(4);

		return data;
	}
}
