package exception1;

import java.io.*;

public class MyException extends Exception {
    public MyException(String msg) {
        super(msg);
    }
}