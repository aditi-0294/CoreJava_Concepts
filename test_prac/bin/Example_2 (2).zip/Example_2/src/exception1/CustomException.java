package exception1;

import java.io.*;

public class CustomException {
    public static void main(String[ ] args) throws Exception {
        CustomException cusException = new CustomException( );
        cusException.displayNum( );
    }

    public void displayNum( ) throws MyException {
        for(int i = 0; i < 10; i++) {
            System.out.println(i);
            if(i == 5) {
                throw new MyException("Custom Exception Thrown");
            }
        }
    }
}