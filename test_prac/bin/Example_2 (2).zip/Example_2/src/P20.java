import java.time.LocalDate;
import java.time.Month;
import java.time.Period;

public class P20 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		LocalDate date = LocalDate.of(2016, Month.OCTOBER, 31);
        LocalDate lastHalloween = date.minusMonths(12);
        lastHalloween.plusMonths(1);
        Period period = Period.between(lastHalloween, date);
        System.out.println(period);
        System.out.println(lastHalloween);
	}

}
