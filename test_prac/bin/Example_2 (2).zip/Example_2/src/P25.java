import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;

public class P25 {

	public static void main(String args[]) {
		
	}
	 String[ ] x = {"This is the first element.", "The lazy brown fox.", "The name of this array is x."};
	          OutputStreamWriter sw;
	          try {
	              sw = new OutputStreamWriter(new FileOutputStream("E:\\Mastek\\Files\\P25.txt"));
	  
	         } catch (IOException e) {
	              System.out.println(e.getMessage( ));
	          }
}
