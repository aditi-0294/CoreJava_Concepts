import java.util.function.ToIntFunction;

public class P24 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String s = "Hello World!";
        ToIntFunction<String> index = s::indexOf;
        double test = index.applyAsInt("o");
        System.out.print(test);
	}

}
