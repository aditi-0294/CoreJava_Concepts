import java.util.ArrayDeque;
import java.util.Deque;

public class P4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Deque deque = new ArrayDeque(5); // 2,1,3,5,7,8
        deque.add(1);
        deque.addFirst(2);
        deque.add(3);
        deque.add(5);
        deque.addLast(7);
        deque.add(8);    // line n1

        deque.peek( );
        deque.remove( );
        deque.pop( );
        deque.poll( );

      //  for (Integer number : deque) {     // line n2
        for(Object number : deque){
        System.out.println("Number = " + number);
        }
	}

}
