import java.util.function.BiFunction;

public class P31 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		 BiFunction<Double, Double, Integer> compareDoubles = Double::compare;
	        System.out.println(compareDoubles.apply(12.0, 12.0));
	}

}
