import java.util.Arrays;
import java.util.List;
import java.util.function.Function;

public class P2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		List<String> months = Arrays.asList("January", "March", "July");
        Function<String, Integer> monthLength = s -> s.length();
        Function<Integer, Boolean> filter = i -> i < 5;
        Function<String, Boolean> test = monthLength.andThen(filter);
        months.stream( )
              .map(test)
              .forEach(System.out::print);
	}

}
