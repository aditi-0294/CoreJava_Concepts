import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.function.Predicate;
import java.util.function.Supplier;

public class P27 {

	public static <A extends Collection<Integer>, B extends Collection<Integer>> B calc(A source, Predicate<Integer> tester, Supplier<B> dest) {
		 
		         B res = dest.get( );
		 
		        for(Integer s: source) {
		             if(tester.test(s)) {
		                 res.add(s);
		             }
		         }
		 
		         return res;
		     }
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		List<Integer> list = new ArrayList( );
		         list.add(2);
		         list.add(5);
		         list.add(10);
		         list.add(17);
		 
		         List<Integer> res = calc(list,  s -> s % 2 == 0, ArrayList::new);
		 
		         res.stream( ).forEach(s -> { System.out.println(s); });
		     }
	}

