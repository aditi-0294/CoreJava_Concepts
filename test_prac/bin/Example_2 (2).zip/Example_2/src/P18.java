import java.util.Arrays;
import java.util.List;

public class P18 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		List<String> employeeList = Arrays.asList("13 : Dave : Programmer", "20 : John, Finance",
				"31 : Cathy : Human Resources");
		employeeList.stream().filter(s -> s.contains("r")).sorted().forEach(s -> System.out.println(s));
	}

}
