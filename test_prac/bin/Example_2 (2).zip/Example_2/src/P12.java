import java.time.Instant;
import java.time.OffsetDateTime;
import java.time.ZoneId;

public class P12 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Instant i = Instant.now() ;
		ZoneId z = ZoneId.of("Canada/Vancouver");
		OffsetDateTime o = OffsetDateTime.ofInstant(i, z) ;
		System.out.println(o);
	}

}
