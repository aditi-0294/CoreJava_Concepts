
public class P8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		OuterClass outer = new OuterClass();
		OuterClass.InnerClass inner = new OuterClass.InnerClass();
		outer.outerMethod();
		inner.innerMethod();
	}

}

class OuterClass {
     int outerVar = 5;
 
     public void outerMethod( ) {
         System.out.println("outer: " + outerVar++);
     }
 
     static class InnerClass {
         public void innerMethod( ) {
             System.out.println("inner: " + outerVar);
         }
     }
}