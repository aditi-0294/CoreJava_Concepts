package dmy;

public class MyClass {
     public static void main(String[ ] args) {
         validatePerson("John", "Smith");
     }
 
     public static void validatePerson(String fName, String lName) {
         class Person {
             String name;
             Person(String name) {
                this.name = name;
             }
   
             String getName( ) {
                 return name;
             }
 
             public void printPerson( ) {
                 System.out.print(fName + " " + lName);
             }
 
         }
 
         Person person = new Person(fName);
 
         if(person.getName( ).length() <= 4) {
            System.out.println(person.getName( ) + " is too short.");
         } else {
            person.printPerson( );
            System.out.println(" is valid.");
         }
     }
 }