import java.util.Locale;
import java.util.ResourceBundle;

public class P30 {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub

		Locale cl = new Locale("en", "CA") ;
		System.out.println(cl);
		
		ResourceBundle rb = 
		System.out.println(rb.getString("Greeting"));
	}

}
