import java.nio.file.FileSystems;
import java.nio.file.Path;

public class P29 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String a = "/Windows/System32" ;
		Path p = FileSystems.getDefault().getPath(a) ;
		
		System.out.println(p.getName(1));
	}

}
