import java.util.ArrayList;

public class P32 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ArrayList ml = new ArrayList() ;
		
		ml.add(1);
		ml.add(2);
		ml.add(3);
		ml.remove(1);
		
		for(Object b : ml) {
			System.out.println(b + " ");
		}
	}

}
