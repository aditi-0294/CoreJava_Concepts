import java.util.ArrayList;
import java.util.List;

public class P9 {

	   public static void main(String[ ] args) {
	         List<Integer> l1 = new ArrayList( );
	         List<Integer> l2 = new ArrayList( );
	 
		         l1.add(1);
		         l1.add(4);
		        l1.add(8);
		         l1.add(12);
		 
		         l2.add(6);
		         l2.add(3);
		         l2.add(2);
		         l2.add(0);
		 
		 
		         List<Integer> list = myMethod(l1, l2, (a, b) -> a * b);
		         
		         if(list != null) {
		             list.stream( ).forEach(p -> System.out.println(p));
		         } else {
	             System.out.println("Error with sizes");
	         }
		
	}
		 
		
		public static List<Integer> myMethod(List<Integer> l1, List<Integer> l2, BinaryOperator<Integer> op) {
		         List<Integer> l3 = new ArrayList( );
		 
		         if(l1.size( ) != l2.size( )) {
		             return null;
		         } else {
		             for(int i = 0; i < l1.size( ); i++) {
		                 l3.add(op.apply(l1.get(i), l2.get(i)));
		             }
	             return l3;
	         }
}
