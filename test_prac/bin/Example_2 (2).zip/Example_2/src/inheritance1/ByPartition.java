package inheritance1;

import java.util.*;
import java.util.stream.Collectors;

 public class ByPartition {
     public static void main(String[] args){
         Character[] chars = new Character[] { 'a', 'b', 'c', 'd', 'e', 'f', 'g'};
        		 Map<Boolean, List<Character>> partitions = Arrays
         }
         .stream(chars)
         .collect(Collectors.partitioningBy((Character x) -> x < 'd', Collectors.toList()));
         System.out.println(partitions);
     }
 }
