package inheritance1;

public class MyClass {
	public static void main(String[] args) {
		Fish fish = new Fish();
		fish.eat();
	}

	static class Animal {
		public void move() {
			System.out.println("moving");
		}
	}

	static class Fish extends Animal {
		public void move() {
			System.out.println("swimming");
		}

		@Override
		public void eat() {
			System.out.println("fish eating");
		}
	}
}