import java.util.ArrayList;
import java.util.List;
import java.util.function.UnaryOperator;

public class P17 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		List<String> list = new ArrayList();
		list.add("apple");
		list.add("brick");
		list.add("cat");

		myMethod(list, s -> s.charAt(0)).stream().forEach(s -> {
			System.out.println(s);
		});
	}

	public static List<String> myMethod(List<String> list, UnaryOperator<String> up) {

		List<String> l2 = new ArrayList();

		for (String s : list) {
			l2.add(up.apply(s));
		}
		return l2;
	}
}
