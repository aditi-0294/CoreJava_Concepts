package interface1;

import java.util.function.*;

interface FilterString extends Predicate<String> {
    public default boolean test(String str) {
        return str.contains("Success"); 
    }
}
