package interface1;

import java.util.Arrays;
import java.util.List;
import java.util.function.Predicate;

public class P1_1 implements P1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		List<String> str = Arrays.asList("Success Failure", "Successful", "Success");
		Predicate<String> ft1 = s -> s.startsWith("ce", 3);
		Predicate ft2 = new P1() { // line n2
			public boolean test(String s) {
				return s.equals("Success");
			}
		};
		long f = str.stream().filter(ft1).filter(ft2).count();
		System.out.println(f);
	}

}
