package interface1;

import java.util.function.Predicate;

public interface P1 extends Predicate<String> {

	public default boolean test(String str) {
		return str.contains("Success");
	}
}
