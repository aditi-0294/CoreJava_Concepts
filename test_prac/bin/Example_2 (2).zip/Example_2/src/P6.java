import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class P6 {

	
	    String name;
	    int id;

	    P6(String name, int id)
	    {
	         this.name = name;
	         this.id = id;
	    }

	    public String getName( ) {
	        return name;
	    }

	    public int getId( ) {
	        return id;
	    }
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		List<P6> employees = new ArrayList<>( );
        employees.add(new P6("John Doe", 25));
        employees.add(new P6("Jane Jones", 12));
        employees.add(new P6("Roger Price", 41));
        employees.add(new P6("Janet Smith", 56));

    for (P6 e: employees) {
      //  System.out.println(e.getId( ));
    	employees.stream()
    	.map(P6 :: getId)
    	.collect(Collectors.toList());
    	.forEach(System.out::println);
    } 
	}

}
