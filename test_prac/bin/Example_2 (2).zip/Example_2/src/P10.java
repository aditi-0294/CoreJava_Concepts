import java.util.ArrayList;
import java.util.List;

public class P10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		List<Address> addresses = new ArrayList();
		addresses.add(new Address(620, "Mission Street", 100000));
		addresses.add(new Address(3042, "Lower Fortnum Way", 120000));
		addresses.add(new Address(27, "Blvd Montfolfier", 130000));
		addresses.add(new Address(3995, "Arundel Square", 166000));
		addresses.add(new Address(1349, "West Zenith St", 190000));
		addresses.add(new Address(7863, "Scarsdale Heights Freeway", 170000));
		addresses.add(new Address(906, "North Main Street", 188000));

		int sum = addresses.parallelStream()
				.reduce(0, (a, b) -> a + b.getCost(), Integer::sum);

		System.out.println(sum);
	}
}

class Address {
	private int number;
	private String street;
	private int cost;

	public Address(int number, String street, int cost) {
		this.number = number;
		this.street = street;
		this.cost = cost;
	}

	public String getAddress() {
		return this.number + " " + this.street;
	}

	public String getStreet() {
		return this.street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public int getCost() {
		return this.cost;
	}

	public void setCost(int cost) {
		this.cost = cost;
	}
}