import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class P36 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		/*PrintWriter p;
		p = System.console().writer();
		if (Math.random() > 0.5)
			p.println(1);
		else
			p.println(2);
		p.println(3);
		p.close();*/
		
		
		Character[] chars = new Character[] { 'a', 'b', 'c', 'd', 'e', 'f', 'g' };
		         Map<Boolean, List<Character>> partitions = Arrays
		         .stream(chars)
		         .collect(Collectors.partitioningBy((Character x) -> x < 'd', Collectors.toList()));
		         System.out.println(partitions);
	}

}
