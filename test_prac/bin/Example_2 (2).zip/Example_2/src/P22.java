import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;

public class P22 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		 ZonedDateTime zoneDate = LocalDateTime.now( ).atZone(ZoneId.of("Canada/Eastern"));
		  
		         System.out.println(zoneDate.format(DateTimeFormatter.ofPattern(
		        		 "d MMMM yyyy : xxx"
		          )));
	}

}
