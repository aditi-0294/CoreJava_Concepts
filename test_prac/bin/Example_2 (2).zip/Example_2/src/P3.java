import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;

public class P3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String a = "/Java Code";
		Path path = FileSystems.getDefault().getPath(a);

		try {

			Files.walk(path, null);//////
		} catch (IOException e) {
			System.out.println("error: " + e.toString());
		}
	}

}
