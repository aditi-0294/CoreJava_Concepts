import java.util.ArrayDeque;
import java.util.Deque;

public class P19 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Deque<Integer> d = new ArrayDeque<Integer>( ); // 6,4,2,3,5,7
		       P19 test = new P19( );
		       test.fillDeque(d);
		       test.printDeque(d);
		    }
		 
		    void fillDeque(Deque<Integer> a) {
		       a.add(2);
		       a.add(3);
		       a.addFirst(4);
		       a.addLast(5);
		       a.addFirst(6);
		       a.add(7);
		    }
		 
		    void printDeque(Deque<Integer> a) {
		       for(int b = 0; b < a.size(); b++) {
		          System.out.print(a.pollFirst( ) + ", ");
		       }
	}

}
