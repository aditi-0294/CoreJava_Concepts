import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class P23 {

	public static void main(String[] args) {
	List<String> inventory = new ArrayList( );
	 
	         inventory.add("25 pencils");
	         inventory.add("50 books");
	         inventory.add("70 pens");
	         inventory.add("78 calculators");
	 
	         System.out.println(inventory.stream( ).collect(Collectors.joining(", ")));
}
}