import java.util.Map;
import java.util.TreeMap;

public class P5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Map<Integer, String> myMap = new TreeMap< >( );
		         P5 test = new P5( );
		 
		         test.fillMap(myMap); 
		         myMap.put(0, "zero");
		         myMap.put(4, "four");
 
	
		for(Integer myInt: myMap.keySet( )) {
	             System.out.println(myInt + ": " + myMap.get(myInt));
	         }
	     }
		
	
		     void fillMap(Map<Integer, String> myMap) {
		         String[ ] names = {"Bob", "Joe", "Peter"};
		         int counter = 0;
		 
		         for(int i = 2; i > 0; i--) {
		             myMap.put(i, names[counter]);
		             counter++;
		         }
	}

}
