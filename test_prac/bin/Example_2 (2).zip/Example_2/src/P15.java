import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class P15 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		 List<String> sizes = new ArrayList( );
		         List<String> shirts = new ArrayList( );
		         sizes.add("S");
		         sizes.add("L");
		 
		         shirts.add("Shirt 1");
		         shirts.add("Shirt 2");
		 
		         System.out.println(shirts.parallelStream( ).
		             flatMap(s -> sizes.stream( ).map(t -> s + " (" + t + ")")).
		             collect(Collectors.joining(", ")));
	}

}
