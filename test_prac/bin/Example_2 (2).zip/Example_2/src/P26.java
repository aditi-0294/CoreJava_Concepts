import java.util.Arrays;
import java.util.List;
import java.util.function.ToDoubleFunction;

public class P26 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		 List<String> months = Arrays.asList("January", "March", "July");
	        ToDoubleFunction<String> tdf = str -> str.length( );
	        double result = months.stream( )
	                              .mapToDouble(tdf)    // line n1
	                              .sum( );   // line n2
	        System.out.print(result);
	}

}
