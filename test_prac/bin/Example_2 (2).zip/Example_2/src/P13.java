import javax.management.BadStringOperationException;

public class P13 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String[] names = {"Alex", "Liz", "Ed", "Sam"};
		         System.out.print("Names: ");
		 
		         for(String s: names) {
		             try {
		                 isValid(s);
		                 System.out.print(s + " ");
		             } catch(BadStringOperationException e) {
		                 System.out.println( );
		                 System.out.print(e.toString( ));
		                 break;
		             }
		         }
		     }
		 
		     static boolean isValid(String s)
		     {
		         if (s.length( ) < 3) {
		             throw new BadStringOperationException("The name " + s + " is too short.");
		         }
		         return true;
		     }
		}
