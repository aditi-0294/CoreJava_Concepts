
public class P28 {

	static void n(Long l) {
		System.out.println("Long");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int a = 18 ;
		n(a);
	}

}
