import java.util.ArrayDeque;
import java.util.Deque;

public class P21 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Deque<Integer> deque = new ArrayDeque<>();
        deque.add(1);
        deque.addFirst(2);
        deque.add(1);
        deque.add(5);
        deque.offer(9);
        deque.push(8);
        deque.poll( );
        deque.remove(1);
        deque.pop( );
        deque.poll( );
        deque.remove(4);    // line n1

        for (Object number : deque) {     // line n2
            System.out.println("Number = " + number);
        }
	}

}
