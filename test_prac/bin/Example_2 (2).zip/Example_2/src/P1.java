
public class P1 {

	//final int min = 0 ;
	int min = 0;
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		P1 test = new P1();
		test.min = -999;
		System.out.println(test.min);
	}

}
