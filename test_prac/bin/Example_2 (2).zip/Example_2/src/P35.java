import java.util.Arrays;
import java.util.List;
import java.util.function.Supplier;

public class P35 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		List<String> names = Arrays.asList("Peter", "Paul", "Mary");
        names.stream( )
             .filter(s -> s.length( ) == 4)
             .forEach(s -> printNames(( ) -> s));
    }
    static void printNames(Supplier s1) {
	   // line n1
    	System.out.println(s1.get());
	}

}
