import java.util.ArrayList;
import java.util.List;

public class P7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		List<String> list = new ArrayList( );
		        list.add("Tim");
		         list.add("Bob");
		         list.add("Frank");
		         list.add("Jill");
		 
		        list.stream( ).peek(s -> System.out.println(s));
	}

}
