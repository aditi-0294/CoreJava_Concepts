/**
 * 
 */

console.log("app.js file loaded") ;

var app = angular.module('myApp' , []) ;

console.log("app.js - myApp loaded") ;

/*app.value("username") ;*/