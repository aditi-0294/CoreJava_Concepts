/**
 * 
 */

var myApp = angular.module('myApp', []);

myApp.factory('Data', function () {
  return { message: "I'm data from a service" }
});

function firstController($scope, Data) {
  $scope.data = Data;
}

function secondController($scope, Data) {
  $scope.data = Data;
}