package com.niit.DummyProject.model;

import org.hibernate.validator.constraints.NotEmpty;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.dropwizard.Configuration;

public class ProductConfiguration extends Configuration {

	@NotEmpty
	private String productName ;
	
	@NotEmpty
	private int productId ;
	
	@NotEmpty
	private int productPrice ;
	
	@JsonProperty
	public String getProductName() {
		return productName;
	}
	
	@JsonProperty
	public void setProductName(String productName) {
		this.productName = productName;
	}
	
	@JsonProperty
	public int getProductId() {
		return productId;
	}
	
	@JsonProperty
	public void setProductId(int productId) {
		this.productId = productId;
	}
	
	@JsonProperty
	public int getProductPrice() {
		return productPrice;
	}
	
	@JsonProperty
	public void setProductPrice(int productPrice) {
		this.productPrice = productPrice;
	}
	
}
