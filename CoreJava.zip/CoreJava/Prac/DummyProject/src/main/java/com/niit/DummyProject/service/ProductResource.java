package com.niit.DummyProject.service;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.hibernate.validator.constraints.NotEmpty;

import com.codahale.metrics.annotation.Timed;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.niit.DummyProject.model.ProductConfiguration;


@Path("/Product")
@Produces(MediaType.APPLICATION_JSON)

public class ProductResource {

	private static final String ProductConfiguration = null;

	@NotEmpty
	private String productName ;
	
	@NotEmpty
	private int productId ;
	
	@NotEmpty
	private int productPrice ;

	public ProductResource(String productName, int productId, int productPrice) {
		super();
		this.productName = productName;
		this.productId = productId;
		this.productPrice = productPrice;
	}

	@GET
	@Timed
	
	public Response<>() {
		
		return new Response.ok
	}

	
	
	
}
