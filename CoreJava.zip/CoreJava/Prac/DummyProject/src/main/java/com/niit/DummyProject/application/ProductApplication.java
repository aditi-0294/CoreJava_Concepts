package com.niit.DummyProject.application;

import com.niit.DummyProject.model.ProductConfiguration;

import io.dropwizard.Application;
import io.dropwizard.setup.Environment;

public class ProductApplication extends Application<ProductConfiguration>{

	public static void main(String args[]) throws Exception {
		
		new ProductApplication().run(args);
	}
	
	@Override
	public void run(ProductConfiguration configuration, Environment environment) throws Exception {
		// TODO Auto-generated method stub
		
		environment.jersey().register(configuration);
	}

	
}
