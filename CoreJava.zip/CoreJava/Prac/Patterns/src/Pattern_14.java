import java.util.Scanner;

public class Pattern_14 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner input = new Scanner(System.in) ;
		
		System.out.print("Enter number of lines : ");
		int lines = input.nextInt() ;
		
		System.out.println("The pattern is : ");
		
		for(int row = lines ; row > 0 ; row--) {
			
			for(int column = row ; column > 0 ; column--) {
				
				System.out.print(column);
			}
			
			System.out.println();
		}

	}

}

/* Patter starts 

Enter number of lines : 7
The pattern is : 
7654321
654321
54321
4321
321
21
1

Pattern ends */