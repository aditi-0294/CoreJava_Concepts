import java.util.Scanner;

public class Pattern_8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner input = new Scanner(System.in) ;
		
		System.out.print("Enter number of lines : ");
		int lines = input.nextInt() ;
		
		System.out.println("The pattern is : ");

	//	int spaces = 2 * lines - 2 ;
		
		for(int row = 1 ; row <= lines ; row++) {
			
			for(int column = 0 ; column < lines-row ; column++) {
				
				System.out.print("1 ");
			}
			
			//spaces = spaces - 2 ;
			
			for(int column = 0 ; column < row ; column++) {
				
				System.out.print(row + " ");
			
			}
			
			System.out.println();		
		}
	}

}

/* Pattern starts
Enter number of lines : 5
The pattern is : 
1 1 1 1 1 
1 1 1 2 2 
1 1 3 3 3 
1 4 4 4 4 
5 5 5 5 5 

Pattern ends */