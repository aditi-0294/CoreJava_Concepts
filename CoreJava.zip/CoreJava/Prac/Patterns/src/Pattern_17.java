import java.util.Scanner;

public class Pattern_17 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner input = new Scanner(System.in) ;
		
		System.out.print("Enter number of lines : ");
		int lines = input.nextInt() ;
		
		for(int row = 1 ; row <= lines ; row++) {
			
			for(int column = 1 ; column <= row ; column++) {
				
				System.out.print(column);
				
			}
			
			
			for(int column_2 = row - 1 ; column_2 >= 1 ; column_2--) {
				
				System.out.print(column_2);
				
			}
			
			System.out.println();
		}

	}

}


/* Pattern start

Enter number of lines : 5
1
121
12321
1234321
123454321

Pattern ends */