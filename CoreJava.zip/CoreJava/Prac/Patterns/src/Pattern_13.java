import java.util.Scanner;

public class Pattern_13 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner input = new Scanner(System.in) ;
		
		System.out.print("Enter number of lines : ");
		int lines = input.nextInt() ;
		
		for(int row = 1 ; row <= lines ; row++) {
			
			int num = lines ;
			
			for(int column = 1 ; column <= row ; column++) {
				
				System.out.print(num);
				num-- ;
				
			}
			
			System.out.println();
		}

	}

}

/* PAttern starts 

Enter number of lines : 5
5
54
543
5432
54321

Pattern ends */