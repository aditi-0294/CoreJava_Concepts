import java.util.Scanner;

public class Pattern_21 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner input = new Scanner(System.in) ;
		
		System.out.println("Enter number of lines : ");
		int lines = input.nextInt() ;
		
		System.out.println("The pattern is : ");
		
		for(int row = 1 ; row <= lines ; row++) {
			
			for(int column = 1 ; column < row ; column++) {
				
				System.out.print(" ");
				
			}
			
			for(int column = row ; column <= lines ; column++) {
				
				System.out.print(column);
			
			}
			
			System.out.println();
		}
		
		
		for(int row = lines - 1 ; row > 0 ; row--) {
			
			for(int column = 1 ; column < row ; column++) {
				
				System.out.print(" ");
			
			}
			
			for(int column = row ; column <= lines ; column++) {
				
				System.out.print(column);
			
			}
			
			System.out.println();
		}
		

	}

}

/* Pattern start 

Enter number of lines : 
7
The pattern is : 
1234567
 234567
  34567
   4567
    567
     67
      7
     67
    567
   4567
  34567
 234567
1234567

Pattern ends */