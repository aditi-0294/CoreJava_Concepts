import java.util.Scanner;

public class Pattern_12 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner input = new Scanner(System.in) ;
		
		System.out.println("Enter number of lines : ");
		int lines = input.nextInt() ;
		
		System.out.println("The pattern is : ");
		
		for(int row = lines ; row > 0 ; row--) {
			
			int num = lines ;
			for(int column = 1 ; column <= row ; column++) {
				
				System.out.print(num);
				num-- ;
				
			}
			
			System.out.println();
		}
	}

}

/* Pattern starts
Enter number of lines : 
7
The pattern is : 
7654321
765432
76543
7654
765
76
7
Pattern ends */