import java.util.Scanner;

public class Pattern_11 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner input = new Scanner(System.in) ;
		
		System.out.print("Enter number of lines : ");
		int lines = input.nextInt() ;

		System.out.println("The pattern is : ");
		
		for(int row = lines ; row > 0 ; row--) {
			
			int num = 1 ;
			
			for(int column = 1 ; column <= row ; column++) {
				
				System.out.print(num);
				num++ ;
				
			}
			
			System.out.println();
		}
	}

}


/* Pattern starts
 
 Enter number of lines : 5
The pattern is : 
12345
1234
123
12
1
 
Pattern ends */