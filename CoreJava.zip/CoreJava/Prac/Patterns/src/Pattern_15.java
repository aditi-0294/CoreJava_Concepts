import java.util.Scanner;

public class Pattern_15 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner input = new Scanner(System.in) ;
		
		System.out.print("Enter number of lines : ");
		int lines = input.nextInt() ;
		
		for(int row = lines ; row > 0 ; row--) {
			
			for(int column = 1 ; column <= row ; column++) {
				
				System.out.print(column);
			}
			
			System.out.println();
		}
				
		for(int row = 2 ; row <= lines ; row++) {
			
			for(int column = 1 ; column <= row ; column++) {
				
				System.out.print(column);
			}
			
			System.out.println();
		}

	}

}

/* Pattern start

Enter number of lines : 5
12345
1234
123
12
1
12
123
1234
12345

Pattern ends */