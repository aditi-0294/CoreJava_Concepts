import java.util.Scanner;

public class Pattern_26 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner input = new Scanner(System.in) ;
		
		System.out.println("Enter number of lines : ");
		int lines = input.nextInt() ;
		
		System.out.println("The pattern is : ");
		
		for(int row = 1 ; row <= lines ; row++) {
			
			int num = row ;
			
			for(int column = 1 ; column <= row ; column++) {
				
				System.out.print(num + " ");
				num = num + lines - column ;
			}
			
			System.out.println();
		}

	}

}
