import java.util.Scanner;

public class Pattern_6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner input = new Scanner(System.in) ;
		
		System.out.print("Enter number of lines : ");
		int lines = input.nextInt() ;

		for(int row = 0 ; row < lines ; row++) {
			
			//int num = 1 ;
			
			for(int column = 0 ; column <= row ; column++) {
				
				int num = 1 ;
				System.out.print(num + " "); // replace by 'A'
				num++ ;
			
			}
			
			System.out.println();
		}
	}

}

/* Pattern starts
Enter number of lines : 5
1 
1 1 
1 1 1 
1 1 1 1 
1 1 1 1 1 

Pattern ends */