package calculator;

import java.util.Scanner;

public class Calculator implements calculator_method {

	@Override
	public double addition(double num_1, double num_2) {
		// TODO Auto-generated method stub
		return (num_1 + num_2) ;
	}

	@Override
	public double subtraction(double num_1, double num_2) {
		// TODO Auto-generated method stub
		return (num_1 - num_2) ;
	}

	@Override
	public double multimlication(double num_1, double num_2) {
		// TODO Auto-generated method stub
		return (num_1 * num_2) ;
	}

	@Override
	public double division(double num_1, double num_2) {
		// TODO Auto-generated method stub
		return (num_1 / num_2);
	}

	public static void main(String[] args) {
		
		Calculator cal = new Calculator() ;
		
		Scanner sc = new Scanner(System.in) ; 
		
		System.out.println(" ****** CALCULATOR PROGRAM ****** ");
		
		System.out.println();
		
			
	//	String val = "";
		
		double num_1;
		double num_2;
		
		int choice = 0;
		
	//	String val ;
		char val ;
		
		do {
			
			System.out.println("Enter arithematic operation to be performed : ");
			System.out.println("1. Addition");
			System.out.println("2. Subtraction");
			System.out.println("3. Multiplication");
			System.out.println("4. Division");
			System.out.println("5. Exit");
		
			System.out.println();
		
			try {
			
				System.out.println("Enter choice : ");
				choice = sc.nextInt() ;
				
			}catch(Exception e) {
				System.out.println("Cant' take string values .... " + e);
				System.out.println();
			}
			
			switch(choice) {
				
			case 1 :
				System.out.println("Enter first number : ");
				num_1 = sc.nextDouble() ;
				
				System.out.println("Enter second number : ");
				num_2 = sc.nextDouble() ;
		
				System.out.println("Addition of two numbers : " + cal.addition(num_1, num_2));
				
				break ;
				
			case 2 :
				System.out.println("Enter first number : ");
				num_1 = sc.nextDouble() ;
				
				System.out.println("Enter second number : ");
				num_2 = sc.nextDouble() ;
		
				System.out.println("Subtraction of two numbers : " + cal.subtraction(num_1, num_2));
				break ;
				
			case 3 :
				System.out.println("Enter first number : ");
				num_1 = sc.nextDouble() ;
				
				System.out.println("Enter second number : ");
				num_2 = sc.nextDouble() ;
		
				System.out.println("Multiplication of two numbers : " + cal.multimlication(num_1, num_2));
				break ;
				
			case 4 :
				System.out.println("Enter first number : ");
				num_1 = sc.nextDouble() ;
				
				System.out.println("Enter second number : ");
				num_2 = sc.nextDouble() ;
		
				System.out.println("Division of two numbres : " + cal.division(num_1, num_2));
				break ;
				
		//	case 5 :
			//	System.exit(0);
			//	break ;
				
			default :
				System.out.println("Pls. enter correct option .... ");
				break ;
				
				}
			/*
			if(choice == 1 || choice == 2 || choice == 3 || choice == 4) {
				
				System.out.println();
				System.out.println();
				System.out.println("Press 'y' or 'Y' to continue .... ");
				val = sc.next() ;
				System.out.println();
				System.out.println("=================================================");
				
				System.out.println();
				
				System.out.println("Continued ..... ");
				System.out.println();
				
			}
			
			else {
				
				System.out.println("And try again .... ");
				System.out.println();
				
				System.out.println("=================================================");
				//System.out.println();
				//System.out.println();
				System.out.println("Continued ..... ");
				System.out.println();
								
			}
			*/
			
			System.out.println("Press 'y' or 'Y' to continue .... ");
			val = sc.next().charAt(0) ;
			System.out.println();
			System.out.println("=================================================");
			System.out.println();
			System.out.println("Continued");
			System.out.println();
			
			
	//	}while(choice != 5) ;
		}while(val == 'Y'|| val == 'y') ;


	}

}
