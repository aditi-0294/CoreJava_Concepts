package calculator;

public interface calculator_method {
	
	public double addition(double num_1 , double num_2) ;

	public double subtraction(double num_1 , double num_2) ;
	
	public double multimlication(double num_1 , double num_2) ;
	
	public double division(double num_1 , double num_2) ;

}
