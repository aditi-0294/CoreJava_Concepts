
public class p2 {

	/*p2() {
		
		static int i = 1 ;
		System.out.println(i);

	}
*/	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	
	/*	double i = 10 ;
		byte t = (byte)i ;
	*/	
	
		byte i = 10 ;
		double t = (double)i ;
		
		System.out.println(i + " " + t);
		/*System.out.println("welcome!");
		int index = 0;
		int Length = 0;
		int j = 0;
		char RevString = '\0';
		char tempString = '\0';
		char[] temp = new char[] { 'a', 'b', 'c', 'd', 'e', 'f', '\0' };
		// String temp = "Welcome to cluster";
		while ('\0' != temp[index])
			index++;
		Length = index;
		System.out.println("String Length = " + Length);
		for (index = 0; index < Length; Length--, index++) {

			RevString = temp[index];
			temp[index] = temp[Length - 1];
			temp[Length] = RevString;
			tempString = temp[index];
			System.out.println("reversed string isss " + temp[index]); // System.out.println("Reversed
																		// string
																		// : "+
																		// RevString);
		}
*/
	}

}
