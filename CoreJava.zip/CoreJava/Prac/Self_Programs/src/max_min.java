import java.util.Scanner;

public class max_min {
	
	public void largest_smallest_number() {
		
		Scanner sc = new Scanner(System.in) ;
		
		System.out.println("Enter range of numbers : "); // total elements present in range
		int limit = sc.nextInt() ;
		
		System.out.println("Enter " + limit + " numbers : "); // value of elements
		int num = sc.nextInt() ; // first number
		//int temp = num ;
		
		int max = 0;
		int min = 0 ;
		
		for(int i = 2 ; i <= limit ; i++) {
			num = sc.nextInt() ;
			
			if(num > max)
				max = num ;
			
			if(num < min)
				min = num ;
			
		}
		
		System.out.println("Max number = " + max);
		System.out.println("Min number = " + min);
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		max_min mn = new max_min() ;
		mn.largest_smallest_number();

	}

}
