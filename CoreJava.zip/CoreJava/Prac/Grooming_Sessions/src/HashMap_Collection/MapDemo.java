package HashMap_Collection;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.HashMap;
import java.util.Scanner;

public class MapDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		HashMap<Integer,Employee> hashMap = new HashMap<Integer,Employee>() ;
		
		/*
		hashMap.put(1001, new Employee(1001 , "Aditi" , 23000)) ;
		hashMap.put(1002, new Employee(1002 , "Aarina" , 20000)) ;
		hashMap.put(1003, new Employee(1003 , "Khushi" , 19000)) ;
		hashMap.put(1004, new Employee(1004 , "Karan" , 45000)) ;
		
		*/
		
		
		try {
			
			BufferedReader br = new BufferedReader(new FileReader("E:\\NIIT\\Programs\\Files\\hashMap\\EmployeeInfo_hashMap.txt")) ;
			String record ;
			
			while((record=br.readLine())!=null) {
				
				System.out.println(record);

				//	String employeeRecord[] = record.split(",") ;
				
				String employeeRecord[] = record.split(",") ;
				
				try {
					
				
					int emp_id = Integer.parseInt(employeeRecord[0]) ;
				
					double salary = Double.parseDouble(employeeRecord[2]) ;
				
					Employee employee = new Employee(emp_id,employeeRecord[1],salary) ;
				
					hashMap.put(emp_id,employee) ;
				
				} catch(NumberFormatException ne) {
					
						System.out.println("Not a number !!!!");
					
				}
				
				
			}
			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		int employeeId ;
		
		do {
			
			System.out.println("Enter Employee Id. : ");
			Scanner sc = new Scanner(System.in) ;
			employeeId = sc.nextInt() ;
			
			displayEmployeeInfo(employeeId , hashMap) ;
			
			System.out.println();
			
		} while(true) ;
		
		
	}

	public static void displayEmployeeInfo(int employeeId, HashMap<Integer, Employee> employee_list) {
		// TODO Auto-generated method stub
		
		Employee employee = (Employee)employee_list.get(employeeId) ;
		System.out.println(employee);
		
	}

}
