package ArrayList_Collection;

import java.util.Comparator;

public class NameWiseSort implements Comparator<Employee> {

	@Override
	public int compare(Employee arg0, Employee arg1) {
		// TODO Auto-generated method stub
		//return 0;
		
		return arg0.emp_name.compareTo(arg1.emp_name) ;
	}

}
