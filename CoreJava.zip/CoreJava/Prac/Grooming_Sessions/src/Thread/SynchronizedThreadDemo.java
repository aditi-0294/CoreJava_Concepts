package Thread;

class sync {
	
	public static synchronized void display() {
		
		for(int i = 0 ; i <= 10 ; i++) {
			
			System.out.println("Value of i for " + Thread.currentThread().getName() + " = " + i);
			
			try {
				
				Thread.sleep(2000);
			
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
	}
}

public class SynchronizedThreadDemo extends Thread {
	
	public void run() {
		
		sync.display();
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		SynchronizedThreadDemo sdt1 = new SynchronizedThreadDemo() ;
		sdt1.setName("A");
		sdt1.start();
		
		SynchronizedThreadDemo sdt2 = new SynchronizedThreadDemo() ;
		sdt2.setName("B");
		sdt2.start();
		
	}

}
