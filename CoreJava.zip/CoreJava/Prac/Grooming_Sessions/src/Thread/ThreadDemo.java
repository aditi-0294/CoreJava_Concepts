package Thread;

public class ThreadDemo extends Thread {
	
	public void run() {
		
		for(int i = 0; i <= 2 ; i++) {
			
			System.out.println("value of i for " + Thread.currentThread().getName() + " = " + i);
			
			try {
				
				Thread.sleep(10000);
			
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ThreadDemo td1 = new ThreadDemo() ;
		td1.setName("A");
		td1.setPriority(MAX_PRIORITY);
		td1.start();
		
		System.out.println();
		
		ThreadDemo td2 = new ThreadDemo() ;
		td2.setName("B");
		td2.setPriority(MIN_PRIORITY);
		td2.start();
		
		System.out.println();
		
		ThreadDemo td3 = new ThreadDemo() ;
		td3.setName("C");
		td3.setPriority(NORM_PRIORITY);
		td3.start();
		
		System.out.println();
		
		ThreadDemo td4 = new ThreadDemo() ;
		td4.setName("D");
		td4.setPriority(1);
		td4.start();
		
		System.out.println();
		
		ThreadDemo td5 = new ThreadDemo() ;
		td5.setName("E");
		td5.setPriority(MAX_PRIORITY); // setPriority cant' be zero if MIN_PRIORITY is used 
		td5.start();
		
		System.out.println();
	}

}
