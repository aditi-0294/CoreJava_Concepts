package One;

import java.util.TreeMap;

public class P2 extends java.util.TreeSet {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		java.util.TreeSet t = new java.util.TreeSet();
        t.clear();

	}
	
	 public void clear() 
	    {
	        TreeMap m = new TreeMap();
	        m.clear();
	    }

}
