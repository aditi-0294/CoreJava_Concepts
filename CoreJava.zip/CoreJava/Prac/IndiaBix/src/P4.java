
public class P4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		 String s1 = new String("abc");
	        String s2 = "abc";
	        String s3 = "abc";
	        if (s1==s2)
	            System.out.println("s1==s2");
	        if(s1==s3)
	            System.out.println("s1==s3");
	        if(s2==s3)
	            System.out.println("s2==s3");

	}

}
